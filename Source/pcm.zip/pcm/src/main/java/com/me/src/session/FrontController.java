/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.me.src.session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author prakashj
 */
public class FrontController {
	private static final Logger logger = LoggerFactory.getLogger(FrontController.class);
    
    public void callService() {
                        
        logger.info("received request for: ");
    }        
}
