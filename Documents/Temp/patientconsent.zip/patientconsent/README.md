patientconsent
==============

Engineering Secure Systems final project on centralized patient consent management system.