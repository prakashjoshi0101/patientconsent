package com.me.src.pojo;

public class Allergy {

}
